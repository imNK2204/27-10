const user = [
    {
        username:"user1",
        password:"pass1",
        name:'josh',
        age:'28'
    },
    {
        username:'user2',
        password:'pass2',
        name:'josh',
        age:'21'
    },
    {
        username:'user3',
        password:'pass3',
        name:'user3',
        age:'20'
    },
    {
        username:'user4',
        password:'pass4',
        name:'josh',
        age:'22'
    }, 
    {
        username:'user5',
        password:'pass5',
        name:'user5',
        age:'25'
    }

];
module.exports = user;